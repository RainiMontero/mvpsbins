document.addEventListener('DOMContentLoaded', () => {
    const accordionButtons = document.querySelectorAll('#accordionExample .accordion-button');

    accordionButtons.forEach(button => {
      button.addEventListener('click', () => {
        setTimeout(() => {
          const target = document.querySelector(button.getAttribute('data-bs-target'));
          const radio = button.querySelector('input[type=radio]');
          if (target.classList.contains('show')) {
            radio.checked = true;
          } else {
            radio.checked = false;
          }
        }, 300); // A small delay to ensure the collapse transition completes
      });
    });

    const accordionItems = document.querySelectorAll('#accordionExample .accordion-collapse');

    accordionItems.forEach(item => {
      item.addEventListener('shown.bs.collapse', () => {
        const radio = item.parentElement.querySelector('input[type=radio]');
        radio.checked = true;
      });

      item.addEventListener('hidden.bs.collapse', () => {
        const radio = item.parentElement.querySelector('input[type=radio]');
        radio.checked = false;
      });
    });
  });