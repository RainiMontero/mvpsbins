document.addEventListener("DOMContentLoaded", function () {
    const stickyElement = document.getElementById("price-pdp");
    const header = document.getElementById("header");

    function addDynamicMargin() {
        const headerHeight = header.offsetHeight;
        const scrollPosition = window.scrollY;

        if (scrollPosition > headerHeight) {
            stickyElement.classList.add("contPrStky");
            stickyElement.style.top = `${headerHeight - 2}px`;
        } else {
            stickyElement.classList.remove("contPrStky");
            stickyElement.style.top = "0";
        }
    }

    window.addEventListener("scroll", addDynamicMargin);
    // Call once to ensure the class is applied if the page is loaded with scroll
    addDynamicMargin();


});

/* Calcular precio del plan */
// Mostrar o ocultar el botón de borrado del primer asegurado

// Insertar opciones desde 18 hasta 79 al input de edad contratante
const edadSelect = document.getElementById('edad-cli');

for (let i = 18; i <= 79; i++) {
    const option = document.createElement('option');
    option.value = i;
    option.text = i;
    edadSelect.appendChild(option);
}

// Marcar la opción de 18 por defecto en el input de edad contratante
edadSelect.value = 18;

document.addEventListener('DOMContentLoaded', function () {
    const addMoreAseBtn = document.getElementById('addMoreAse');
    const aseguradosCont = document.getElementById('aseguradosCont');
    const maxAsegurados = 7;
    const valorUf = 37538; // Valor de la UF

    const pricePesos = document.getElementById('pricePesos');
    const pricePesosMb = document.getElementById('pricePesosMb');
    const cantUf = document.getElementById('cantUf');
    const priceUfMb = document.getElementById('priceUfMb');
    const previPdp = document.getElementById('previPdp');
    const edadCli = document.getElementById('edad-cli');

    const toggleAddButtonVisibility = () => {
        const currentAsegurados = aseguradosCont.querySelectorAll('.custom-select-container').length;
        if (currentAsegurados >= maxAsegurados) {
            addMoreAseBtn.style.display = 'none';
        } else {
            addMoreAseBtn.style.display = 'block';
        }
    };

    const renumerarAsegurados = () => {
        const asegurados = aseguradosCont.querySelectorAll('.custom-select-container');
        asegurados.forEach((asegurado, index) => {
            const newIndex = index + 1;
            asegurado.id = `contAse${newIndex}`;
            asegurado.querySelector('.btn-close').id = `dlt-Ase${newIndex}`;
            asegurado.querySelector('.btn-close').setAttribute('data-counter', newIndex);
            asegurado.querySelector('.form-select').id = `parentA${newIndex}`;
            asegurado.querySelector('.form-label[for^="nombre"]').setAttribute('for', `nombreA${newIndex}`);
            asegurado.querySelector('input[id^="nombre"]').id = `nombreA${newIndex}`;
            asegurado.querySelector('.form-label[for^="apellido"]').setAttribute('for', `apellidoA${newIndex}`);
            asegurado.querySelector('input[id^="apellido"]').id = `apellidoA${newIndex}`;
            asegurado.querySelector('.form-label[for^="edad"]').setAttribute('for', `edadA${newIndex}`);
            asegurado.querySelector('input[id^="edad"]').id = `edadA${newIndex}`;
            // Añadir evento para inputs de edad
            asegurado.querySelector('input[id^="edad"]').addEventListener('input', calcularPrecio);
        });
        toggleAddButtonVisibility();
        calcularPrecio(); // Actualizar precio después de renumerar
    };

    const calcularPrecio = () => {
        let edad = parseInt(edadCli.value) || 0;
        const prevision = previPdp.value;

        // Revisar todos los inputs de edad de los asegurados
        const inputsEdad = aseguradosCont.querySelectorAll('input[id^="edadA"]');
        inputsEdad.forEach(input => {
            const inputEdadValue = parseInt(input.value) || 0;
            if (inputEdadValue > edad) {
                edad = inputEdadValue;
            }
        });

        let ufValue = 0;

        if (prevision === 'fonasa') {
            if (edad > 79) ufValue = 11.48;
            else if (edad > 69) ufValue = 7.86;
            else if (edad > 59) ufValue = 3.02;
            else if (edad > 49) ufValue = 1.81;
            else if (edad > 39) ufValue = 0.91;
            else if (edad > 17) ufValue = 0.60;
        } else if (prevision === 'isapre') {
            if (edad > 79) ufValue = 9.67;
            else if (edad > 69) ufValue = 6.04;
            else if (edad > 59) ufValue = 2.42;
            else if (edad > 49) ufValue = 1.36;
            else if (edad > 39) ufValue = 0.76;
            else if (edad > 17) ufValue = 0.45;
        }

        cantUf.textContent = ufValue;
        pricePesos.textContent = new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(Math.ceil(ufValue * valorUf));

        //Precios Pesos Mobile
        priceUfMb.textContent = ufValue;
        pricePesosMb.textContent = new Intl.NumberFormat('es-CL', {
            style: 'currency',
            currency: 'CLP',
            minimumFractionDigits: 0,
            maximumFractionDigits: 0
        }).format(Math.ceil(ufValue * valorUf));
    };

    // Evento para el botón de cierre predeterminado
    document.getElementById('dlt-Ase1').addEventListener('click', function () {
        const counterValue = this.getAttribute('data-counter');
        const contAse = document.getElementById(`contAse${counterValue}`);
        contAse.querySelectorAll('input').forEach(input => input.value = '');
        contAse.remove();
        renumerarAsegurados();
    });

    addMoreAseBtn.addEventListener('click', function () {
        const currentAsegurados = aseguradosCont.querySelectorAll('.custom-select-container').length;

        if (currentAsegurados < maxAsegurados) {
            const newIndex = currentAsegurados + 1;
            const newAseguradoHtml = `
                <div class="row justify-content-center border rounded p-3 pt-5 custom-select-container mt-5"
                    id="contAse${newIndex}">
                    <div class="closeCont">
                        <button type="button" class="btn-close" aria-label="Close"
                            id="dlt-Ase${newIndex}" data-counter="${newIndex}"></button>
                    </div>
                    <select class="form-select mb-3" id="parentA${newIndex}" required>
                        <option selected disabled value="">Selecciona parentezco</option>
                        <option value="hijo">Hijo</option>
                        <option value="conyuge">Cónyuge</option>
                        <option value="padre">Padre</option>
                    </select>
                    <div class="col-12 col-md-6 col-lg-5 mb-3">
                        <label for="nombreA${newIndex}" class="form-label fw6 cprimary">Nombre</label>
                        <input type="text" class="form-control" id="nombreA${newIndex}" required>
                    </div>
                    <div class="col-8 col-md-6 col-lg-4 mb-3">
                        <label for="apellidoA${newIndex}" class="form-label fw6 cprimary">Apellido</label>
                        <input type="text" class="form-control" id="apellidoA${newIndex}" required>
                    </div>
                    <div class="col-4 col-md-6 col-lg-3 mb-3">
                        <label for="edadA${newIndex}" class="form-label fw6 cprimary">Edad</label>
                        <input type="number" class="form-control" id="edadA${newIndex}" required>
                    </div>
                </div>
            `;
            aseguradosCont.insertAdjacentHTML('beforeend', newAseguradoHtml);

            document.getElementById(`dlt-Ase${newIndex}`).addEventListener('click', function () {
                const counterValue = this.getAttribute('data-counter');
                const contAse = document.getElementById(`contAse${counterValue}`);
                contAse.querySelectorAll('input').forEach(input => input.value = '');
                contAse.remove();
                renumerarAsegurados();
            });

            // Añadir evento para el nuevo input de edad
            document.getElementById(`edadA${newIndex}`).addEventListener('input', calcularPrecio);

            toggleAddButtonVisibility();
        }
    });

    // Añadir evento al input de edad predeterminado
    document.getElementById('edadA1').addEventListener('input', calcularPrecio);

    previPdp.addEventListener('change', calcularPrecio);
    edadCli.addEventListener('input', calcularPrecio);

    // Inicializar la visibilidad del botón al cargar la página
    toggleAddButtonVisibility();

    //Detectar el check de la respuesta "NO" de la ultima pregunta
    const q3Pdp = document.getElementById('q3-pdp');
    const donePdp = document.getElementById('done-pdp');
    const triqSi = document.getElementById('q3-dps-pdp-Si');
    const triqNo = document.getElementById('q3-dps-pdp-No');
    function toggleContent3q() {
        if (triqNo.checked) {
            q3Pdp.classList.add('hidden');
            q3Pdp.classList.remove('flexDps');
            donePdp.classList.remove('hidden');
            dpsAlert.classList.remove('show');
            dpsBox.classList.remove('shadow-drop-2-center');
        } else {
            q3Pdp.classList.remove('hidden');
            donePdp.classList.add('hidden');
        }
    }
    triqSi.addEventListener('change', toggleContent3q);
    triqNo.addEventListener('change', toggleContent3q);
});


// PASOS DE LA DPS
$(document).ready(function () {
    function updateNextButton(containerId) {
        $(`#${containerId} .form-check-input`).on('change', function () {
            $(`#${containerId} .btn-false`).addClass('hidden');
            $(`#${containerId} .btn-next`).removeClass('hidden');
        });
    }

    function showContainer(hideId, showId) {
        $(`#${hideId}`).addClass('hidden');
        $(`#${hideId}`).removeClass('flexDps');
        $(`#${showId}`).removeClass('hidden');
        $(`#${showId}`).addClass('flexDps');
    }

    updateNextButton('q1-pdp');
    updateNextButton('q2-pdp');
    updateNextButton('q3-pdp');

    $('#nxtQ2').on('click', function () {
        if ($('#q1-dps-pdp-No').is(':checked')) {
            showContainer('q1-pdp', 'q2-pdp');
        } else if ($('#q1-dps-pdp-Si').is(':checked')) {
            showContainer('q1-pdp', 'fail-pdp');
        }
    });

    $('#nxtQ3').on('click', function () {
        if ($('#q2-dps-pdp-No').is(':checked')) {
            showContainer('q2-pdp', 'q3-pdp');
        } else if ($('#q2-dps-pdp-Si').is(':checked')) {
            showContainer('q2-pdp', 'fail-pdp');
        }
    });

    $('#nxtDone').on('click', function () {
        if ($('#q3-dps-pdp-No').is(':checked')) {
            showContainer('q3-pdp', 'done-pdp');
        } else if ($('#q3-dps-pdp-Si').is(':checked')) {
            showContainer('q3-pdp', 'fail-pdp');
        }
    });

    $('#bckQ1').on('click', function () {
        showContainer('q2-pdp', 'q1-pdp');
    });

    $('#bckQ2').on('click', function () {
        showContainer('q3-pdp', 'q2-pdp');
    });

    $('#bckQ3').on('click', function () {
        showContainer('fail-pdp', 'q1-pdp');
    });
    $('#bckDone').on('click', function () {
        showContainer('done-pdp', 'q3-pdp');
    });
});

//formulario envio
// Validar si las opciones de radio están todas en "No"
function validateRadioButtons() {
    for (let i = 1; i <= 3; i++) {
        if (!document.getElementById(`q${i}-dps-pdp-No`).checked) {
            return false;
        }
    }
    return true;
}

const dpsBox = document.getElementById('dpsQuestions');
const dpsAlert = document.getElementById('alertDPS');



// Manejo del envío del formulario
document.getElementById('insuranceForm').addEventListener('submit', function (event) {
    event.preventDefault();
    if (this.checkValidity()) {
        if (validateRadioButtons()) {
            // Obtener los valores de los elementos del formulario
            const pricePesosLs = document.getElementById('pricePesos').innerText;
            const cantUfLs = document.getElementById('cantUf').innerText;
            const previsionLs = document.getElementById('previPdp').value;
            const edadCliLs = document.getElementById('edad-cli').value;

            // Crear un array para almacenar los asegurados
            let aseguradosLs = [];
            const aseguradosCont = document.getElementById('aseguradosCont');
            const aseguradosDivs = aseguradosCont.querySelectorAll('.row[id^="contAse"]');

            aseguradosDivs.forEach((div) => {
                const parent = div.querySelector('select').value;
                const nombre = div.querySelector('input[id^="nombreA"]').value;
                const apellido = div.querySelector('input[id^="apellidoA"]').value;
                const edad = div.querySelector('input[id^="edadA"]').value;

                if (parent && nombre && apellido && edad) { // Verificar que todos los campos estén llenos
                    aseguradosLs.push({
                        parentezco: parent,
                        nombre: nombre,
                        apellido: apellido,
                        edad: edad
                    });
                }
            });

            // Crear un objeto con todos los datos
            const formData = {
                pricePesos: pricePesosLs,
                cantUf: cantUfLs,
                prevision: previsionLs,
                edadCli: edadCliLs,
                asegurados: aseguradosLs
            };

            // Almacenar el objeto en el localStorage
            localStorage.setItem('insuranceFormData', JSON.stringify(formData));


            // Resetear el formulario
            this.reset();
            dpsAlert.classList.remove('show');
            dpsBox.classList.remove('shadow-drop-2-center');
            // Obtener el elemento del offcanvas
            const offcanvasElement = document.getElementById('drawer-cart');
            const bsOffcanvas = new bootstrap.Offcanvas(offcanvasElement);
            // Mostrar el offcanvas
            bsOffcanvas.show();
        } else {
            dpsBox.classList.remove('shadow-drop-2-center');
            void dpsBox.offsetWidth;
            dpsBox.classList.add('shadow-drop-2-center');
            dpsAlert.classList.remove('show');
            void dpsAlert.offsetWidth;
            dpsAlert.classList.add('show');
        }
    } else {
        this.reportValidity();
    }
});


// Para cargar los datos almacenados al cargar la página
/*window.addEventListener('load', function () {
    const storedData = localStorage.getItem('insuranceFormData');
    if (storedData) {
        const formData = JSON.parse(storedData);
        document.getElementById('pricePesos').innerText = formData.pricePesos;
        document.getElementById('cantUf').innerText = formData.cantUf;
        document.getElementById('previPdp').value = formData.prevision;
        document.getElementById('edad-cli').value = formData.edadCli;

        const aseguradosCont = document.getElementById('aseguradosCont');
        const aseguradosDivs = aseguradosCont.querySelectorAll('.row[id^="contAse"]');

        formData.asegurados.forEach((asegurado, index) => {
            if (index < aseguradosDivs.length) {
                const div = aseguradosDivs[index];
                div.querySelector('select').value = asegurado.parentezco;
                div.querySelector('input[id^="nombreA"]').value = asegurado.nombre;
                div.querySelector('input[id^="apellidoA"]').value = asegurado.apellido;
                div.querySelector('input[id^="edadA"]').value = asegurado.edad;
            }
        });
    }
});*/

//Cambiar el formulario de contenedor según la resolución de la pantalla
function moveForm() {
    const form = document.getElementById('insuranceForm');
    const formDesk = document.getElementById('formDesk');
    const formMb = document.getElementById('formMb');
    
    if (window.innerWidth <= 768) { // Puedes ajustar el tamaño según tus necesidades
        if (form.parentNode !== formMb) {
            formMb.appendChild(form);
        }
    } else {
        if (form.parentNode !== formDesk) {
            formDesk.appendChild(form);
        }
    }
}

// Ejecutar la función al cargar la página y al cambiar el tamaño de la ventana
window.addEventListener('load', moveForm);
window.addEventListener('resize', moveForm);

//Cambiar el texto del submit del formulario en versión mobile
document.addEventListener('DOMContentLoaded', function () {
    const form = document.getElementById('insuranceForm');
    const llenaDataButton = document.getElementById('llenaData');

    function checkFormCompletion() {
        const inputs = form.querySelectorAll('input');
        const selects = form.querySelectorAll('select');
        let allFilled = true;

        inputs.forEach(input => {
            if ((input.type === 'text' || input.type === 'email') && !input.value.trim()) {
                allFilled = false;
            }
        });

        // Para los radio buttons, aseguramos que al menos uno esté seleccionado
        const radioGroups = Array.from(new Set(Array.from(inputs)
            .filter(input => input.type === 'radio')
            .map(input => input.name)));

        radioGroups.forEach(groupName => {
            const radios = form.querySelectorAll(`input[name="${groupName}"]`);
            if (!Array.from(radios).some(radio => radio.checked)) {
                allFilled = false;
            }
        });

        selects.forEach(select => {
            if (!select.value) {
                allFilled = false;
            }
        });

        llenaDataButton.textContent = allFilled ? 'Agregar al carro' : 'Llena tus datos';
    }

    form.addEventListener('input', checkFormCompletion);
    form.addEventListener('change', checkFormCompletion);

    // Inicialmente chequeamos el formulario
    checkFormCompletion();
});