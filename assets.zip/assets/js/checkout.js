//Regiones y comunas de Chile
const comunasPorRegion = {
  15: ["Arica", "Camarones", "Putre", "General Lagos"],
  1: ["Iquique", "Alto Hospicio", "Pozo Almonte", "Huara", "Camiña", "Colchane", "Pica"],
  2: ["Antofagasta", "Mejillones", "Sierra Gorda", "Taltal", "Calama", "Ollagüe", "San Pedro de Atacama", "Tocopilla", "María Elena"],
  3: ["Copiapó", "Caldera", "Tierra Amarilla", "Chañaral", "Diego de Almagro", "Vallenar", "Huasco", "Freirina", "Alto del Carmen"],
  4: ["La Serena", "Coquimbo", "Andacollo", "La Higuera", "Paiguano", "Vicuña", "Illapel", "Canela", "Los Vilos", "Salamanca", "Ovalle", "Combarbalá", "Monte Patria", "Punitaqui", "Río Hurtado"],
  5: ["Valparaíso", "Casablanca", "Concón", "Juan Fernández", "Puchuncaví", "Quintero", "Viña del Mar", "Isla de Pascua", "Los Andes", "Calle Larga", "Rinconada", "San Esteban", "La Ligua", "Cabildo", "Papudo", "Petorca", "Zapallar", "Quillota", "La Calera", "Hijuelas", "La Cruz", "Nogales", "San Antonio", "Algarrobo", "Cartagena", "El Quisco", "El Tabo", "Santo Domingo", "San Felipe", "Catemu", "Llaillay", "Panquehue", "Putaendo", "Santa María", "Quilpué", "Limache", "Olmué", "Villa Alemana"],
  13: ["Cerrillos", "Cerro Navia", "Conchalí", "El Bosque", "Estación Central", "Huechuraba", "Independencia", "La Cisterna", "La Florida", "La Granja", "La Pintana", "La Reina", "Las Condes", "Lo Barnechea", "Lo Espejo", "Lo Prado", "Macul", "Maipú", "Ñuñoa", "Pedro Aguirre Cerda", "Peñalolén", "Providencia", "Pudahuel", "Quilicura", "Quinta Normal", "Recoleta", "Renca", "San Joaquín", "San Miguel", "San Ramón", "Santiago", "Vitacura", "Puente Alto", "Pirque", "San José de Maipo", "Colina", "Lampa", "Tiltil", "San Bernardo", "Buin", "Calera de Tango", "Paine", "Melipilla", "Alhué", "Curacaví", "María Pinto", "San Pedro", "Talagante", "El Monte", "Isla de Maipo", "Padre Hurtado", "Peñaflor"],
  6: ["Rancagua", "Codegua", "Coinco", "Coltauco", "Doñihue", "Graneros", "Las Cabras", "Machalí", "Malloa", "Mostazal", "Olivar", "Peumo", "Pichidegua", "Quinta de Tilcoco", "Rengo", "Requínoa", "San Vicente", "Pichilemu", "La Estrella", "Litueche", "Marchihue", "Navidad", "Paredones", "San Fernando", "Chépica", "Chimbarongo", "Lolol", "Nancagua", "Palmilla", "Peralillo", "Placilla", "Pumanque", "Santa Cruz"],
  7: ["Talca", "Constitución", "Curepto", "Empedrado", "Maule", "Pelarco", "Pencahue", "Río Claro", "San Clemente", "San Rafael", "Cauquenes", "Chanco", "Pelluhue", "Curicó", "Hualañé", "Licantén", "Molina", "Rauco", "Romeral", "Sagrada Familia", "Teno", "Vichuquén", "Linares", "Colbún", "Longaví", "Parral", "Retiro", "San Javier", "Villa Alegre", "Yerbas Buenas"],
  16: ["Cobquecura", "Coelemu", "Ninhue", "Portezuelo", "Quirihue", "Ránquil", "Treguaco", "Bulnes", "Chillán", "Chillán Viejo", "El Carmen", "Pemuco", "Pinto", "Quillón", "San Ignacio", "Yungay", "San Carlos", "Coihueco", "Ñiquén", "San Fabián", "San Nicolás"],
  8: ["Concepción", "Coronel", "Chiguayante", "Florida", "Hualqui", "Lota", "Penco", "San Pedro de la Paz", "Santa Juana", "Talcahuano", "Tomé", "Hualpén", "Lebu", "Arauco", "Cañete", "Contulmo", "Curanilahue", "Los Álamos", "Tirúa", "Los Ángeles", "Antuco", "Cabrero", "Laja", "Mulchén", "Nacimiento", "Negrete", "Quilaco", "Quilleco", "San Rosendo", "Santa Bárbara", "Tucapel", "Yumbel", "Alto Biobío"],
  9: ["Temuco", "Carahue", "Cunco", "Curarrehue", "Freire", "Galvarino", "Gorbea", "Lautaro", "Loncoche", "Melipeuco", "Nueva Imperial", "Padre Las Casas", "Perquenco", "Pitrufquén", "Pucón", "Saavedra", "Teodoro Schmidt", "Toltén", "Vilcún", "Villarrica", "Cholchol", "Angol", "Collipulli", "Curacautín", "Ercilla", "Lonquimay", "Los Sauces", "Lumaco", "Purén", "Renaico", "Traiguén", "Victoria"],
  14: ["Valdivia", "Corral", "Lanco", "Los Lagos", "Máfil", "Mariquina", "Paillaco", "Panguipulli", "La Unión", "Futrono", "Lago Ranco", "Río Bueno"],
  10: ["Puerto Montt", "Calbuco", "Cochamó", "Fresia", "Frutillar", "Los Muermos", "Llanquihue", "Maullín", "Puerto Varas", "Castro", "Ancud", "Chonchi", "Curaco de Vélez", "Dalcahue", "Puqueldón", "Queilén", "Quellón", "Quemchi", "Quinchao", "Osorno", "Puerto Octay", "Purranque", "Puyehue", "Río Negro", "San Juan de la Costa", "San Pablo", "Chaitén", "Futaleufú", "Hualaihué", "Palena"],
  11: ["Coyhaique", "Lago Verde", "Aysén", "Cisnes", "Guaitecas", "Cochrane", "O'Higgins", "Tortel", "Chile Chico", "Río Ibáñez"],
  12: ["Punta Arenas", "Laguna Blanca", "Río Verde", "San Gregorio", "Cabo de Hornos", "Antártica", "Porvenir", "Primavera", "Timaukel", "Natales", "Torres del Paine"]
};

document.getElementById('region').addEventListener('change', function () {
  const regionId = this.value;
  const comunaSelect = document.getElementById('comuna');

  // Limpiar opciones previas
  comunaSelect.innerHTML = '<option value="" selected disabled>Selecciona tu comuna de residencia</option>';

  if (comunasPorRegion[regionId]) {
    comunasPorRegion[regionId].forEach(comuna => {
      const option = document.createElement('option');
      option.value = comuna;
      option.textContent = comuna;
      comunaSelect.appendChild(option);
    });
  }
});

//acordeón metodos
document.addEventListener('DOMContentLoaded', () => {
  const accordionButtons = document.querySelectorAll('#accordionExample .accordion-button');

  accordionButtons.forEach(button => {
      button.addEventListener('click', () => {
          setTimeout(() => {
              const target = document.querySelector(button.getAttribute('data-bs-target'));
              const radio = button.querySelector('input[type=radio]');
              if (target.classList.contains('show')) {
                  radio.checked = true;
              } else {
                  radio.checked = false;
              }
              updateRequiredFields();
          }, 300); // A small delay to ensure the collapse transition completes
      });
  });

  const accordionItems = document.querySelectorAll('#accordionExample .accordion-collapse');

  accordionItems.forEach(item => {
      item.addEventListener('shown.bs.collapse', () => {
          const radio = item.parentElement.querySelector('input[type=radio]');
          radio.checked = true;
          updateRequiredFields();
      });

      item.addEventListener('hidden.bs.collapse', () => {
          const radio = item.parentElement.querySelector('input[type=radio]');
          radio.checked = false;
          updateRequiredFields();
      });
  });

  const updateRequiredFields = () => {
      const cardInputs = [
          document.getElementById('cardName'),
          document.getElementById('cardNumber'),
          document.getElementById('expiryDate'),
          document.getElementById('cvv')
      ];

      if (document.getElementById('radioBuCard').checked) {
          cardInputs.forEach(input => {
              input.setAttribute('required', 'required');
          });
      } else {
          cardInputs.forEach(input => {
              input.removeAttribute('required');
          });
      }
  };

  // Initial state check
  updateRequiredFields();
});



//Variables para el cambio de los formularios del checkout
// pasos descktop breadcrumbs
const step1 = document.getElementById('checkStep1');
const step2 = document.getElementById('checkStep2');
const step3 = document.getElementById('checkStep3');

// pasos descktop breadcrumbs Mobile
const step1M = document.getElementById('checkStep1M');
const step2M = document.getElementById('checkStep2M');
const step3M = document.getElementById('checkStep3M');

// contenedores de formularios
const contForm1 = document.getElementById('checkForm1Cont');
const contForm2 = document.getElementById('checkForm2Cont');
const contForm3 = document.getElementById('checkForm3Cont');

//Contenedor de métodos de envio
const shippBox = document.getElementById('shipMethodBox');

// subtmits de formularios
const submitForm1 = document.getElementById('submitForm1Cont');
const submitForm2 = document.getElementById('submitForm2Cont');
const submitForm3 = document.getElementById('submitForm3Cont');




//envio del primer formulario del checkout
document.getElementById('checkForm1').addEventListener('submit', function (event) {
  event.preventDefault(); // Previene el envío del formulario para demostración

  // Aquí puedes añadir lógica para validar el formulario manualmente si es necesario
  if (this.checkValidity()) {
    form1Ready();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    // Descomentar la siguiente línea para permitir el envío del formulario
    // this.submit();
  } else {
    alert('Por favor, completa todos los campos requeridos.');
  }
});

function form1Ready() {
  submitForm1.classList.add('hidden');
  submitForm2.classList.remove('hidden');
  contForm1.classList.add('hidden');
  contForm2.classList.remove('hidden');
  step1.classList.remove('activo');
  step1.classList.add('activado');
  step2.classList.add('activo');
  step1M.classList.remove('active');
  step1M.classList.add('actived');
  step2M.classList.add('active');
}


//envio del segundo formulario del checkout
document.getElementById('checkForm2').addEventListener('submit', function (event) {
  event.preventDefault(); // Previene el envío del formulario para demostración

  // Aquí puedes añadir lógica para validar el formulario manualmente si es necesario
  if (this.checkValidity()) {
    form2Ready();
    window.scrollTo({ top: 0, behavior: 'smooth' });
    // Descomentar la siguiente línea para permitir el envío del formulario
    // this.submit();
  } else {
    alert('Por favor, completa todos los campos requeridos.');
  }
});

function form2Ready() {
  submitForm2.classList.add('hidden');
  submitForm3.classList.remove('hidden');
  contForm2.classList.add('hidden');
  contForm3.classList.remove('hidden');
  step2.classList.remove('activo');
  step2.classList.add('activado');
  step3.classList.add('activo');
  step2M.classList.remove('active');
  step2M.classList.add('actived');
  step3M.classList.add('active');
}



//envio del Tercer formulario del checkout
document.getElementById('checkForm3').addEventListener('submit', function (event) {
  event.preventDefault(); // Previene el envío del formulario para demostración
  // Obtén todos los checkboxes con el nombre 'envioOptions'
  const checkboxes = document.querySelectorAll('input[name="envioOptions"]');

  // Verifica si al menos uno está seleccionado
  const isChecked = Array.from(checkboxes).some(checkbox => checkbox.checked);

  if (!isChecked) {
    // Si ninguno está seleccionado, muestra una alerta y evita el envío del formulario
    alert('Por favor selecciona al menos una opción de envío.');
    shippBox.classList.remove('shadow-drop-2-center');
    void shippBox.offsetWidth;
    shippBox.classList.add('shadow-drop-2-center');
  } else {
    // Aquí puedes añadir lógica para validar el formulario manualmente si es necesario
    if (this.checkValidity()) {
      window.location.href = 'thankyou.php';
      // Descomentar la siguiente línea para permitir el envío del formulario
      // this.submit();
    } else {
      alert('Por favor, completa todos los campos requeridos.');
    }
  }

});
